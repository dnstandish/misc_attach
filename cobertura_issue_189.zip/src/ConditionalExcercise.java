
public class ConditionalExcercise {

    String s1;

    public ConditionalExcercise() {
    }
    
    public void  excercise() {
        int j;
        j = 2;

        // javac target 1.5 ok, target 1.6 no good, target default no good 
        s1 = new String( j == 2 ? "two" : "not two" );
        
//OK        s1 = new String( true ? "two" : "not two" );

//OK        String s1 = new String( i == 2 ? "two" : "not two" );
        
//OK        s1 = new String( "two" );
        
//OK        s1 = ( i == 2 ? new String("two") : new String("not two") );
        
//OK        s1 = ( i == 2 ? "two" : "not two" );
        
//OK        if ( i == 2 )
//            s1 = new String("two");
//        else 
//            s1 = new String("not two" );
        j = 4;
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        ConditionalExcercise ce = new ConditionalExcercise();
        ce.excercise();
    }
}
